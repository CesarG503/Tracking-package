@extends('layouts.app')

@section('title', 'Vehículos')

@section('content')
<div class="flex gap-6 h-[calc(100vh-10rem)]">
    {{-- Main Table Section --}}
    <div class="flex-1 flex flex-col min-w-0">
        {{-- Header --}}
        <div class="flex items-center justify-between mb-6">
            <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Vehículos</h1>
        </div>

        {{-- Filters --}}
        <div class="liquid-glass-card rounded-2xl p-4 mb-6">
            <form method="GET" class="flex items-center gap-4">
                {{-- Search --}}
                <div class="flex-1 relative">
                    <svg class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                    <input type="text" name="search" value="{{ request('search') }}" placeholder="Buscar vehículo..." class="w-full pl-12 pr-4 py-3 liquid-glass-input rounded-xl">
                </div>

                {{-- Status Filter --}}
                <select name="estado" class="px-4 py-3 liquid-glass-input rounded-xl min-w-[160px] appearance-none cursor-pointer" style="background-image: url('data:image/svg+xml;charset=UTF-8,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%2364748b%27 stroke-width=%272%27%3e%3cpath d=%27M19 9l-7 7-7-7%27/%3e%3c/svg%3e'); background-repeat: no-repeat; background-position: right 12px center; background-size: 16px;">
                    <option value="">Todos los estados</option>
                    <option value="disponible" {{ request('estado') === 'disponible' ? 'selected' : '' }}>Disponible</option>
                    <option value="en_uso" {{ request('estado') === 'en_uso' ? 'selected' : '' }}>En uso</option>
                    <option value="mantenimiento" {{ request('estado') === 'mantenimiento' ? 'selected' : '' }}>Mantenimiento</option>
                    <option value="inactivo" {{ request('estado') === 'inactivo' ? 'selected' : '' }}>Inactivo</option>
                </select>

                {{-- Filter Button --}}
                <button type="submit" class="p-3 liquid-btn-secondary rounded-xl hover:text-indigo-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"/>
                    </svg>
                </button>

                {{-- Add Button --}}
                <a href="{{ route('vehiculos.create') }}" class="liquid-btn-primary px-6 py-3 rounded-xl font-medium flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                    </svg>
                    Agregar
                </a>
            </form>
        </div>

        {{-- Table --}}
        <div class="liquid-glass-card rounded-2xl flex-1 overflow-hidden">
            <div class="overflow-x-auto h-full">
                <table class="liquid-table w-full">
                    <thead>
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider">Nombre</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider">Marca</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider">Año</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider">Placa</th>
                            <th class="px-6 py-4 text-right text-xs font-semibold uppercase tracking-wider">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($vehiculos as $vehiculo)
                        @php
                            $statusColors = [
                                'disponible' => 'status-dot-success',
                                'en_uso' => 'status-dot-info',
                                'mantenimiento' => 'status-dot-warning',
                                'inactivo' => 'status-dot-danger',
                            ];
                        @endphp
                        <tr class="cursor-pointer vehiculo-row" data-id="{{ $vehiculo->id }}" onclick="selectVehiculo({{ $vehiculo->id }}, '{{ $vehiculo->marca }}', '{{ $vehiculo->modelo }}', '{{ $vehiculo->placa }}', '{{ $vehiculo->anio }}', '{{ $vehiculo->estado }}', '{{ addslashes($vehiculo->observaciones) }}', {{ json_encode(json_decode($vehiculo->foto, true) ?? []) }})">
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-3">
                                    <span class="status-dot {{ $statusColors[$vehiculo->estado] ?? 'status-dot-info' }}"></span>
                                    <span class="font-medium text-slate-800 dark:text-white">{{ $vehiculo->modelo }}</span>
                                </div>
                            </td>
                            <td class="px-6 py-4 text-slate-600 dark:text-slate-300">{{ $vehiculo->marca }}</td>
                            <td class="px-6 py-4 text-slate-600 dark:text-slate-300">{{ $vehiculo->anio ?? '-' }}</td>
                            <td class="px-6 py-4">
                                <span class="px-2 py-1 bg-slate-100 dark:bg-slate-700/50 text-slate-700 dark:text-slate-300 rounded font-mono text-sm">{{ $vehiculo->placa }}</span>
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex items-center justify-end gap-2">
                                    <a href="{{ route('vehiculos.show', $vehiculo) }}" class="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-500/10 transition-colors" onclick="event.stopPropagation()">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                        </svg>
                                    </a>
                                    <a href="{{ route('vehiculos.edit', $vehiculo) }}" class="p-2 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-500/10 transition-colors" onclick="event.stopPropagation()">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                        </svg>
                                    </a>
                                    <form action="{{ route('vehiculos.destroy', $vehiculo) }}" method="POST" class="inline" onsubmit="event.stopPropagation(); return confirm('¿Eliminar este vehículo?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="p-2 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                            </svg>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="px-6 py-16 text-center">
                                <div class="flex flex-col items-center">
                                    <div class="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-700/50 flex items-center justify-center mb-4">
                                        <svg class="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"/>
                                        </svg>
                                    </div>
                                    <p class="text-slate-500 mb-4">No hay vehículos registrados</p>
                                    <a href="{{ route('vehiculos.create') }}" class="liquid-btn-primary px-4 py-2 rounded-lg text-sm">Agregar vehículo</a>
                                </div>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            @if($vehiculos->hasPages())
            <div class="px-6 py-4 border-t border-black/5 dark:border-white/5">
                {{ $vehiculos->links() }}
            </div>
            @endif
        </div>
    </div>

    {{-- Preview Panel --}}
    <div class="w-80 flex-shrink-0">
        <div class="liquid-glass-card rounded-2xl p-6 h-full flex flex-col" id="preview-panel">
            {{-- Default state --}}
            <div id="preview-empty" class="flex-1 flex flex-col items-center justify-center text-center">
                <div class="w-20 h-20 rounded-2xl bg-slate-100 dark:bg-slate-700/50 flex items-center justify-center mb-4">
                    <svg class="w-10 h-10 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"/>
                    </svg>
                </div>
                <p class="text-slate-500 text-sm">Selecciona un vehículo para ver sus detalles</p>
            </div>

            {{-- Vehicle details --}}
            <div id="preview-content" class="hidden flex-1 flex flex-col">
                {{-- Image --}}
                <div class="aspect-[4/3] rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-700/50 mb-4">
                    <img id="preview-image" src="/placeholder.svg" alt="" class="w-full h-full object-cover hidden">
                    <div id="preview-no-image" class="w-full h-full flex items-center justify-center">
                        <svg class="w-16 h-16 text-slate-300 dark:text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                        </svg>
                    </div>
                </div>

                {{-- Info --}}
                <h3 id="preview-name" class="text-xl font-bold text-slate-800 dark:text-white mb-2"></h3>
                <p id="preview-desc" class="text-slate-500 text-sm mb-4 line-clamp-3"></p>

                {{-- Details --}}
                <div class="space-y-3 mb-6">
                    <div class="flex items-center justify-between text-sm">
                        <span class="text-slate-500">Marca</span>
                        <span id="preview-marca" class="text-slate-800 dark:text-white font-medium"></span>
                    </div>
                    <div class="flex items-center justify-between text-sm">
                        <span class="text-slate-500">Año</span>
                        <span id="preview-anio" class="text-slate-800 dark:text-white font-medium"></span>
                    </div>
                    <div class="flex items-center justify-between text-sm">
                        <span class="text-slate-500">Placa</span>
                        <span id="preview-placa" class="text-slate-800 dark:text-white font-mono bg-slate-100 dark:bg-slate-700/50 px-2 py-0.5 rounded"></span>
                    </div>
                    <div class="flex items-center justify-between text-sm">
                        <span class="text-slate-500">Estado</span>
                        <span id="preview-estado" class="flex items-center gap-2">
                            <span class="status-dot" id="preview-status-dot"></span>
                            <span class="text-slate-800 dark:text-white" id="preview-status-text"></span>
                        </span>
                    </div>
                </div>

                {{-- Actions --}}
                <div class="mt-auto flex gap-2">
                    <a id="preview-edit-btn" href="#" class="flex-1 py-2.5 liquid-btn-primary rounded-xl text-center text-sm font-medium">
                        Editar
                    </a>
                    <a id="preview-view-btn" href="#" class="flex-1 py-2.5 liquid-btn-secondary rounded-xl text-center text-sm font-medium">
                        Ver Detalles
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function selectVehiculo(id, marca, modelo, placa, anio, estado, observaciones, fotos) {
    // Update row selection
    document.querySelectorAll('.vehiculo-row').forEach(row => {
        row.classList.remove('selected');
    });
    document.querySelector(`.vehiculo-row[data-id="${id}"]`).classList.add('selected');

    // Show content, hide empty
    document.getElementById('preview-empty').classList.add('hidden');
    document.getElementById('preview-content').classList.remove('hidden');

    // Update content
    document.getElementById('preview-name').textContent = modelo;
    document.getElementById('preview-desc').textContent = observaciones || 'Sin observaciones adicionales';
    document.getElementById('preview-marca').textContent = marca;
    document.getElementById('preview-anio').textContent = anio || '-';
    document.getElementById('preview-placa').textContent = placa;

    // Status
    const statusColors = {
        'disponible': 'status-dot-success',
        'en_uso': 'status-dot-info',
        'mantenimiento': 'status-dot-warning',
        'inactivo': 'status-dot-danger'
    };
    const statusLabels = {
        'disponible': 'Disponible',
        'en_uso': 'En uso',
        'mantenimiento': 'Mantenimiento',
        'inactivo': 'Inactivo'
    };
    const statusDot = document.getElementById('preview-status-dot');
    statusDot.className = 'status-dot ' + (statusColors[estado] || 'status-dot-info');
    document.getElementById('preview-status-text').textContent = statusLabels[estado] || estado;

    // Image
    const imgEl = document.getElementById('preview-image');
    const noImgEl = document.getElementById('preview-no-image');
    if (fotos && fotos.length > 0) {
        imgEl.src = '/storage/' + fotos[0];
        imgEl.classList.remove('hidden');
        noImgEl.classList.add('hidden');
    } else {
        imgEl.classList.add('hidden');
        noImgEl.classList.remove('hidden');
    }

    // Update links
    document.getElementById('preview-edit-btn').href = `/vehiculos/${id}/edit`;
    document.getElementById('preview-view-btn').href = `/vehiculos/${id}`;
}
</script>
@endsection
