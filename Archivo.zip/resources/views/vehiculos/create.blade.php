@extends('layouts.app')

@section('title', 'Nuevo Vehículo')

@section('content')
<div class="max-w-4xl mx-auto">
    {{-- Header --}}
    <div class="flex items-center gap-4 mb-8">
        {{-- Actualizado colores para modo claro --}}
        <a href="{{ route('vehiculos.index') }}" class="w-10 h-10 rounded-xl liquid-btn-secondary flex items-center justify-center hover:text-indigo-600 transition-colors">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
            </svg>
        </a>
        <div>
            <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Nuevo Vehículo</h1>
            <p class="text-slate-500 mt-1">Registra un nuevo vehículo en la flota</p>
        </div>
    </div>

    {{-- Form --}}
    <form action="{{ route('vehiculos.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
        @csrf

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {{-- Left Column - Form Fields --}}
            <div class="liquid-glass-card rounded-2xl p-6 space-y-5">
                {{-- Actualizado colores texto --}}
                <h2 class="text-lg font-semibold text-slate-800 dark:text-white mb-4">Información del Vehículo</h2>

                <div class="grid grid-cols-2 gap-4">
                    {{-- Marca --}}
                    <div>
                        <label for="marca" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Marca *</label>
                        <input type="text" name="marca" id="marca" value="{{ old('marca') }}" required class="w-full px-4 py-3 liquid-glass-input rounded-xl @error('marca') !border-red-500 @enderror" placeholder="Toyota">
                        @error('marca')
                            <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- Modelo --}}
                    <div>
                        <label for="modelo" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Modelo *</label>
                        <input type="text" name="modelo" id="modelo" value="{{ old('modelo') }}" required class="w-full px-4 py-3 liquid-glass-input rounded-xl @error('modelo') !border-red-500 @enderror" placeholder="Hilux">
                        @error('modelo')
                            <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    {{-- Placa --}}
                    <div>
                        <label for="placa" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Placa *</label>
                        <input type="text" name="placa" id="placa" value="{{ old('placa') }}" required class="w-full px-4 py-3 liquid-glass-input rounded-xl font-mono uppercase @error('placa') !border-red-500 @enderror" placeholder="ABC-123">
                        @error('placa')
                            <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- Año --}}
                    <div>
                        <label for="anio" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Año</label>
                        <input type="number" name="anio" id="anio" value="{{ old('anio') }}" min="1900" max="{{ date('Y') + 1 }}" class="w-full px-4 py-3 liquid-glass-input rounded-xl @error('anio') !border-red-500 @enderror" placeholder="{{ date('Y') }}">
                        @error('anio')
                            <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    {{-- Capacidad --}}
                    <div>
                        <label for="capacidad" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Capacidad</label>
                        <input type="text" name="capacidad" id="capacidad" value="{{ old('capacidad') }}" class="w-full px-4 py-3 liquid-glass-input rounded-xl @error('capacidad') !border-red-500 @enderror" placeholder="1000 kg">
                        @error('capacidad')
                            <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- Estado --}}
                    <div>
                        <label for="estado" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Estado *</label>
                        <select name="estado" id="estado" required class="w-full px-4 py-3 liquid-glass-input rounded-xl @error('estado') !border-red-500 @enderror">
                            <option value="disponible" {{ old('estado') === 'disponible' ? 'selected' : '' }}>Disponible</option>
                            <option value="en_uso" {{ old('estado') === 'en_uso' ? 'selected' : '' }}>En uso</option>
                            <option value="mantenimiento" {{ old('estado') === 'mantenimiento' ? 'selected' : '' }}>Mantenimiento</option>
                            <option value="inactivo" {{ old('estado') === 'inactivo' ? 'selected' : '' }}>Inactivo</option>
                        </select>
                        @error('estado')
                            <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                {{-- Observaciones --}}
                <div>
                    <label for="observaciones" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Observaciones</label>
                    <textarea name="observaciones" id="observaciones" rows="4" class="w-full px-4 py-3 liquid-glass-input rounded-xl resize-none @error('observaciones') !border-red-500 @enderror" placeholder="Notas adicionales sobre el vehículo...">{{ old('observaciones') }}</textarea>
                    @error('observaciones')
                        <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            {{-- Right Column - Photos --}}
            <div class="liquid-glass-card rounded-2xl p-6">
                <h2 class="text-lg font-semibold text-slate-800 dark:text-white mb-4">Fotos del Vehículo</h2>

                {{-- Dropzone --}}
                <div class="dropzone-area p-8 text-center cursor-pointer" id="dropzone" onclick="document.getElementById('fotos').click()">
                    <input type="file" name="fotos[]" id="fotos" multiple accept="image/*" class="hidden" onchange="handleFiles(this.files)">
                    <div class="w-16 h-16 mx-auto mb-4 rounded-2xl bg-indigo-100 dark:bg-indigo-500/20 flex items-center justify-center">
                        <svg class="w-8 h-8 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                        </svg>
                    </div>
                    <p class="text-slate-700 dark:text-white font-medium mb-1">Arrastra fotos aquí</p>
                    <p class="text-slate-500 text-sm">o haz clic para seleccionar</p>
                    <p class="text-slate-400 text-xs mt-2">PNG, JPG, WEBP hasta 5MB</p>
                </div>

                {{-- Preview Grid --}}
                <div id="preview-grid" class="grid grid-cols-3 gap-3 mt-4"></div>

                @error('fotos.*')
                    <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>
        </div>

        {{-- Actions --}}
        <div class="flex items-center justify-end gap-3">
            <a href="{{ route('vehiculos.index') }}" class="px-6 py-3 text-slate-600 dark:text-slate-300 font-medium rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                Cancelar
            </a>
            <button type="submit" class="liquid-btn-primary px-8 py-3 rounded-xl font-medium">
                Guardar Vehículo
            </button>
        </div>
    </form>
</div>

<script>
const dropzone = document.getElementById('dropzone');
const input = document.getElementById('fotos');
const previewGrid = document.getElementById('preview-grid');
let selectedFiles = [];

// Drag and drop handlers
['dragenter', 'dragover', 'dragleave', 'drop'].forEach(event => {
    dropzone.addEventListener(event, e => {
        e.preventDefault();
        e.stopPropagation();
    });
});

['dragenter', 'dragover'].forEach(event => {
    dropzone.addEventListener(event, () => dropzone.classList.add('dragging'));
});

['dragleave', 'drop'].forEach(event => {
    dropzone.addEventListener(event, () => dropzone.classList.remove('dragging'));
});

dropzone.addEventListener('drop', e => {
    handleFiles(e.dataTransfer.files);
});

function handleFiles(files) {
    Array.from(files).forEach(file => {
        if (!file.type.startsWith('image/')) return;
        
        selectedFiles.push(file);
        const currentIndex = selectedFiles.length - 1;
        
        const reader = new FileReader();
        reader.onload = e => {
            const div = document.createElement('div');
            div.className = 'image-preview-item aspect-square';
            div.dataset.index = currentIndex;
            div.innerHTML = `
                <img src="${e.target.result}" alt="${file.name}">
                <div class="image-preview-overlay flex items-end justify-center pb-2">
                    <button type="button" onclick="removeFile(${currentIndex}, this)" class="px-2 py-1 bg-red-500 text-white text-xs rounded hover:bg-red-600 transition-colors">
                        Eliminar
                    </button>
                </div>
            `;
            previewGrid.appendChild(div);
        };
        reader.readAsDataURL(file);
    });
    
    updateFileInput();
}

function removeFile(index, btn) {
    selectedFiles[index] = null;
    btn.closest('.image-preview-item').remove();
    updateFileInput();
}

function updateFileInput() {
    const dt = new DataTransfer();
    selectedFiles.filter(f => f !== null).forEach(file => dt.items.add(file));
    input.files = dt.files;
}
</script>
@endsection
