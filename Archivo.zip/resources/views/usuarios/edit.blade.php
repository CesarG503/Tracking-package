@extends('layouts.app')

@section('title', 'Editar Usuario')

@section('content')
<div class="max-w-2xl mx-auto">
    {{-- Header --}}
    <div class="flex items-center gap-4 mb-8">
        {{-- Actualizado colores para modo claro --}}
        <a href="{{ route('usuarios.index') }}" class="w-10 h-10 rounded-xl liquid-btn-secondary flex items-center justify-center hover:text-indigo-600 transition-colors">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
            </svg>
        </a>
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center">
                <span class="text-white font-semibold text-lg">{{ strtoupper(substr($usuario->nombre, 0, 1)) }}</span>
            </div>
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Editar Usuario</h1>
                <p class="text-slate-500 mt-1">{{ $usuario->email }}</p>
            </div>
        </div>
    </div>

    {{-- Form --}}
    <form action="{{ route('usuarios.update', $usuario) }}" method="POST" class="liquid-glass-card rounded-2xl p-6 space-y-6">
        @csrf
        @method('PUT')

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
            {{-- Nombre --}}
            <div class="md:col-span-2">
                <label for="nombre" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Nombre Completo *</label>
                <input type="text" name="nombre" id="nombre" value="{{ old('nombre', $usuario->nombre) }}" required class="w-full px-4 py-3 liquid-glass-input rounded-xl @error('nombre') !border-red-500 @enderror">
                @error('nombre')
                    <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            {{-- Email --}}
            <div>
                <label for="email" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Correo Electrónico *</label>
                <input type="email" name="email" id="email" value="{{ old('email', $usuario->email) }}" required class="w-full px-4 py-3 liquid-glass-input rounded-xl @error('email') !border-red-500 @enderror">
                @error('email')
                    <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            {{-- Teléfono --}}
            <div>
                <label for="telefono" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Teléfono</label>
                <input type="text" name="telefono" id="telefono" value="{{ old('telefono', $usuario->telefono) }}" class="w-full px-4 py-3 liquid-glass-input rounded-xl @error('telefono') !border-red-500 @enderror">
                @error('telefono')
                    <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            {{-- Password --}}
            <div>
                <label for="password" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Nueva Contraseña</label>
                <input type="password" name="password" id="password" class="w-full px-4 py-3 liquid-glass-input rounded-xl @error('password') !border-red-500 @enderror" placeholder="Dejar vacío para mantener">
                @error('password')
                    <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            {{-- Confirm Password --}}
            <div>
                <label for="password_confirmation" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Confirmar Contraseña</label>
                <input type="password" name="password_confirmation" id="password_confirmation" class="w-full px-4 py-3 liquid-glass-input rounded-xl">
            </div>

            {{-- Rol --}}
            <div>
                <label for="rol" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Rol *</label>
                <select name="rol" id="rol" required class="w-full px-4 py-3 liquid-glass-input rounded-xl @error('rol') !border-red-500 @enderror">
                    <option value="repartidor" {{ old('rol', $usuario->rol) === 'repartidor' ? 'selected' : '' }}>Repartidor</option>
                    <option value="admin" {{ old('rol', $usuario->rol) === 'admin' ? 'selected' : '' }}>Administrador</option>
                </select>
                @error('rol')
                    <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            {{-- Licencia --}}
            <div>
                <label for="licencia" class="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Número de Licencia</label>
                <input type="text" name="licencia" id="licencia" value="{{ old('licencia', $usuario->licencia) }}" class="w-full px-4 py-3 liquid-glass-input rounded-xl font-mono @error('licencia') !border-red-500 @enderror">
                @error('licencia')
                    <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>
        </div>

        {{-- Activo --}}
        <div class="flex items-center gap-3">
            <label class="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" name="activo" id="activo" value="1" {{ old('activo', $usuario->activo) ? 'checked' : '' }} class="sr-only peer">
                <div class="w-11 h-6 bg-slate-300 dark:bg-slate-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-indigo-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all after:shadow-sm peer-checked:bg-indigo-500"></div>
            </label>
            <label for="activo" class="text-sm font-medium text-slate-600 dark:text-slate-300">Usuario activo</label>
        </div>

        {{-- Actions --}}
        <div class="flex items-center justify-end gap-3 pt-4 border-t border-black/5 dark:border-white/5">
            <a href="{{ route('usuarios.index') }}" class="px-6 py-3 text-slate-600 dark:text-slate-300 font-medium rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                Cancelar
            </a>
            <button type="submit" class="liquid-btn-primary px-8 py-3 rounded-xl font-medium">
                Actualizar Usuario
            </button>
        </div>
    </form>
</div>
@endsection
